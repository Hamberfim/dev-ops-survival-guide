# Chapter 3

I created the Google authenticator file using the following command.

```bash
google-authenticator -f -t -d -r 3 -R 30 -w 17 -e 10
```
